Dear Reader,



I wish you great fun with learning responsive data visualization! 

Now, you can dive into the code samples for each chapter and play around with them! Try to modify parameters, add custom attributes, custom data sources, etc. to get the most out of it.

In the case you run some of the code files in a browser and you don't see a visual result, please open the Developer Tools (press F12 in Chrome) and check the Console tab.



Best,

Christoph